# Login and Registration Page using Database authentication with Spring Security
Spring Boot Security Login with Database authentication using JPA and connecting to MySQL Database to check whether the Credentials entered are correct to approve the authentication and providing access to the API according to the authority of the User. And also, for new users, providing Registration page and saving the details provided by the user in the Database for Authentication purpose. It also links the API with each other to make it user-friendly and easy to use.

Use the "login2" branch to get the final updated project
